import"./entry.101Kpraf.js";const r=""+new URL("logo.yjEE0l0b.png",import.meta.url).href;export{r as _};
