const client_manifest = {
  "__commonjsHelpers.4gQjN7DL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_commonjsHelpers.4gQjN7DL.js"
  },
  "_header.nlsff_7B.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "header.nlsff_7B.js",
    "imports": [
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_header_2.AI9xFQzh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "header_2.AI9xFQzh.js",
    "imports": [
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_jspdf.plugin.autotable.B7Xwiq1D.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "node_modules/html2canvas/dist/html2canvas.esm.js",
      "node_modules/dompurify/dist/purify.es.js",
      "node_modules/canvg/lib/index.es.js"
    ],
    "file": "jspdf.plugin.autotable.B7Xwiq1D.js",
    "imports": [
      "__commonjsHelpers.4gQjN7DL.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.!~{00S}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "logo.k3mrKkOp.css",
    "src": "_logo.!~{00S}~.js"
  },
  "_logo.WbOHzM7j.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "logo.yjEE0l0b.png"
    ],
    "file": "logo.WbOHzM7j.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "logo.yjEE0l0b.png": {
    "file": "logo.yjEE0l0b.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "_logo.Wn5S2geK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "fa-brands-400.oeevBGvT.woff2",
      "fa-brands-400.xx3GxY8x.ttf",
      "fa-regular-400.PVU4YFxz.woff2",
      "fa-regular-400.uePn0SEG.ttf",
      "fa-solid-900.EFmN-a-a.woff2",
      "fa-solid-900.pvTPbGQT.ttf",
      "fa-v4compatibility.UXWK-ByV.woff2",
      "fa-v4compatibility.ywV-aTaQ.ttf"
    ],
    "css": [
      "logo.k3mrKkOp.css"
    ],
    "file": "logo.Wn5S2geK.js",
    "imports": [
      "_whatsapp.4GWqvSyA.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "logo.k3mrKkOp.css": {
    "file": "logo.k3mrKkOp.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "fa-brands-400.oeevBGvT.woff2": {
    "file": "fa-brands-400.oeevBGvT.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "fa-brands-400.xx3GxY8x.ttf": {
    "file": "fa-brands-400.xx3GxY8x.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "fa-regular-400.PVU4YFxz.woff2": {
    "file": "fa-regular-400.PVU4YFxz.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "fa-regular-400.uePn0SEG.ttf": {
    "file": "fa-regular-400.uePn0SEG.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "fa-solid-900.EFmN-a-a.woff2": {
    "file": "fa-solid-900.EFmN-a-a.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "fa-solid-900.pvTPbGQT.ttf": {
    "file": "fa-solid-900.pvTPbGQT.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "fa-v4compatibility.UXWK-ByV.woff2": {
    "file": "fa-v4compatibility.UXWK-ByV.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "fa-v4compatibility.ywV-aTaQ.ttf": {
    "file": "fa-v4compatibility.ywV-aTaQ.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "_telkom.2W3oFS26.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "telkom.2W3oFS26.js",
    "imports": [
      "__commonjsHelpers.4gQjN7DL.js"
    ]
  },
  "_whatsapp.4GWqvSyA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "whatsapp.4GWqvSyA.js"
  },
  "components/global/table.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "table.87KUJqqk.css"
    ],
    "file": "table.gBkY9xJf.js",
    "imports": [
      "__commonjsHelpers.4gQjN7DL.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/global/table.vue"
  },
  "table.87KUJqqk.css": {
    "file": "table.87KUJqqk.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/MainLayoutBPP.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MainLayoutBPP.Agpuu21w.css"
    ],
    "file": "MainLayoutBPP._AAJSiOa.js",
    "imports": [
      "_logo.Wn5S2geK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/MainLayoutBPP.vue"
  },
  "MainLayoutBPP.Agpuu21w.css": {
    "file": "MainLayoutBPP.Agpuu21w.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/MainLayoutDinas.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MainLayoutDinas.x7vAJr1q.css"
    ],
    "file": "MainLayoutDinas.oeziTw4b.js",
    "imports": [
      "_logo.Wn5S2geK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/MainLayoutDinas.vue"
  },
  "MainLayoutDinas.x7vAJr1q.css": {
    "file": "MainLayoutDinas.x7vAJr1q.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/MainLayoutUser.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MainLayoutUser.NqQMkGGf.js",
    "imports": [
      "_header.nlsff_7B.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/MainLayoutUser.vue"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-brands-400.xx3GxY8x.ttf",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.ttf"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "fa-brands-400.oeevBGvT.woff2",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-brands-400.woff2"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-regular-400.uePn0SEG.ttf",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.ttf"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "fa-regular-400.PVU4YFxz.woff2",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-regular-400.woff2"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-solid-900.pvTPbGQT.ttf",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.ttf"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "fa-solid-900.EFmN-a-a.woff2",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-solid-900.woff2"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "fa-v4compatibility.ywV-aTaQ.ttf",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.ttf"
  },
  "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "fa-v4compatibility.UXWK-ByV.woff2",
    "src": "node_modules/@fortawesome/fontawesome-free/webfonts/fa-v4compatibility.woff2"
  },
  "node_modules/canvg/lib/index.es.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.es.B7yjfN4Z.js",
    "imports": [
      "__commonjsHelpers.4gQjN7DL.js",
      "_jspdf.plugin.autotable.B7Xwiq1D.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/canvg/lib/index.es.js"
  },
  "node_modules/dompurify/dist/purify.es.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "purify.es.pYFWqNIs.js",
    "isDynamicEntry": true,
    "src": "node_modules/dompurify/dist/purify.es.js"
  },
  "node_modules/html2canvas/dist/html2canvas.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "html2canvas.esm.Ry1SfrtC.js",
    "isDynamicEntry": true,
    "src": "node_modules/html2canvas/dist/html2canvas.esm.js"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.3rWqRB8t.css"
    ],
    "dynamicImports": [
      "layouts/MainLayoutBPP.vue",
      "layouts/MainLayoutDinas.vue",
      "layouts/MainLayoutUser.vue"
    ],
    "file": "entry.101Kpraf.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.3rWqRB8t.css": {
    "file": "entry.3rWqRB8t.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/arsip-data/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.SZLscgN7.css"
    ],
    "file": "detail.O77-6YpU.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/arsip-data/detail.vue"
  },
  "detail.SZLscgN7.css": {
    "file": "detail.SZLscgN7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/arsip-data/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "index.ykIct1oJ.css"
    ],
    "file": "index.UK5Yy3YA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/arsip-data/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/arsip-data/index.vue"
  },
  "index.ykIct1oJ.css": {
    "file": "index.ykIct1oJ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/baru/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.aC0QiWmT.css"
    ],
    "file": "detail.JzWlojw6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/baru/detail.vue"
  },
  "detail.aC0QiWmT.css": {
    "file": "detail.aC0QiWmT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/baru/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.WRTBDuPG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/baru/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/baru/index.vue"
  },
  "pages/adminBPP/dashboard/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "detail.2sADIJ8Y.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/dashboard/detail.vue"
  },
  "pages/adminBPP/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.krzbX1U0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/dashboard/index.vue"
  },
  "pages/adminBPP/forget_password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "fa-brands-400.oeevBGvT.woff2",
      "fa-brands-400.xx3GxY8x.ttf",
      "fa-regular-400.PVU4YFxz.woff2",
      "fa-regular-400.uePn0SEG.ttf",
      "fa-solid-900.EFmN-a-a.woff2",
      "fa-solid-900.pvTPbGQT.ttf",
      "fa-v4compatibility.UXWK-ByV.woff2",
      "fa-v4compatibility.ywV-aTaQ.ttf"
    ],
    "css": [
      "forget_password.VZwMvdl5.css"
    ],
    "file": "forget_password.IcleAIUY.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_telkom.2W3oFS26.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/forget_password.vue"
  },
  "forget_password.VZwMvdl5.css": {
    "file": "forget_password.VZwMvdl5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/help/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.YBoIIJTG.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/help/index.vue"
  },
  "pages/adminBPP/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.oBf63cox.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/index.vue"
  },
  "pages/adminBPP/newpassword.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "fa-brands-400.oeevBGvT.woff2",
      "fa-brands-400.xx3GxY8x.ttf",
      "fa-regular-400.PVU4YFxz.woff2",
      "fa-regular-400.uePn0SEG.ttf",
      "fa-solid-900.EFmN-a-a.woff2",
      "fa-solid-900.pvTPbGQT.ttf",
      "fa-v4compatibility.UXWK-ByV.woff2",
      "fa-v4compatibility.ywV-aTaQ.ttf"
    ],
    "css": [
      "newpassword.yXLRHy6r.css"
    ],
    "file": "newpassword.FASXWPmI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_telkom.2W3oFS26.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/newpassword.vue"
  },
  "newpassword.yXLRHy6r.css": {
    "file": "newpassword.yXLRHy6r.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/realisasi/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.iOb6W6gg.css"
    ],
    "file": "detail.mtHOCERY.js",
    "imports": [
      "_jspdf.plugin.autotable.B7Xwiq1D.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/realisasi/detail.vue"
  },
  "detail.iOb6W6gg.css": {
    "file": "detail.iOb6W6gg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/realisasi/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.l2aLS-cB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/realisasi/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js",
      "_jspdf.plugin.autotable.B7Xwiq1D.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/realisasi/index.vue"
  },
  "pages/adminBPP/revisi/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.UzhkxNNW.css"
    ],
    "file": "detail.CqT2zq-2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/revisi/detail.vue"
  },
  "detail.UzhkxNNW.css": {
    "file": "detail.UzhkxNNW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/revisi/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.hxGbh87b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/revisi/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/revisi/index.vue"
  },
  "pages/adminBPP/tervalidasi/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.JVpLV_Cu.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tervalidasi/[id].vue"
  },
  "pages/adminBPP/tervalidasi/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.QXZCqJcT.css"
    ],
    "file": "detail.wZ9-TGI8.js",
    "imports": [
      "_jspdf.plugin.autotable.B7Xwiq1D.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tervalidasi/detail.vue"
  },
  "detail.QXZCqJcT.css": {
    "file": "detail.QXZCqJcT.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/tervalidasi/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.aiMIMxWA.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/tervalidasi/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js",
      "_jspdf.plugin.autotable.B7Xwiq1D.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tervalidasi/index.vue"
  },
  "pages/adminBPP/tidak-valid/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_id_.mSmcD90E.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tidak-valid/[id].vue"
  },
  "pages/adminBPP/tidak-valid/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.ub2Bljvg.css"
    ],
    "file": "detail.4O2Bg8iQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tidak-valid/detail.vue"
  },
  "detail.ub2Bljvg.css": {
    "file": "detail.ub2Bljvg.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminBPP/tidak-valid/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.K1ZBijDW.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutBPP.vue",
      "components/global/table.vue",
      "pages/adminBPP/tidak-valid/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminBPP/tidak-valid/index.vue"
  },
  "pages/adminDinas/arsip-data/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b2TEJO8B.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/arsip-data/index.vue"
  },
  "pages/adminDinas/arsip-data/rincian.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rincian.eM5mjx-3.css"
    ],
    "file": "rincian.2h1n5R0q.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/arsip-data/rincian.vue"
  },
  "rincian.eM5mjx-3.css": {
    "file": "rincian.eM5mjx-3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/baru/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.S0LXzqJY.css"
    ],
    "file": "detail.j3Z0LIDI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/baru/detail.vue"
  },
  "detail.S0LXzqJY.css": {
    "file": "detail.S0LXzqJY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/baru/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.E-aVW9L5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/baru/index.vue"
  },
  "pages/adminDinas/dashboard/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.2U14UQKi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/dashboard/index.vue"
  },
  "pages/adminDinas/help/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.JsefynrP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/help/index.vue"
  },
  "pages/adminDinas/import-data/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.G3YUiNiD.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/import-data/index.vue"
  },
  "pages/adminDinas/realisasi/Pengumuman_hasil.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Pengumuman_hasil.vRFFh3vO.css"
    ],
    "file": "Pengumuman_hasil.B_PvsScN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/realisasi/Pengumuman_hasil.vue"
  },
  "Pengumuman_hasil.vRFFh3vO.css": {
    "file": "Pengumuman_hasil.vRFFh3vO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/realisasi/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.dpjfGZkV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/realisasi/index.vue"
  },
  "pages/adminDinas/rekap-data/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.BHaOw6Si.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/rekap-data/index.vue"
  },
  "pages/adminDinas/rekap-data/rincian.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "rincian.1tGmdETj.css"
    ],
    "file": "rincian.cK7Rx_A0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/rekap-data/rincian.vue"
  },
  "rincian.1tGmdETj.css": {
    "file": "rincian.1tGmdETj.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/sumber-dana/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.CP6_MUqJ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/sumber-dana/index.vue"
  },
  "pages/adminDinas/tervalidasi/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.QqMe39OE.css"
    ],
    "file": "detail.9ldVH-A_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/tervalidasi/detail.vue"
  },
  "detail.QqMe39OE.css": {
    "file": "detail.QqMe39OE.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/tervalidasi/form_realisasi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "form_realisasi.WP_GPllY.css"
    ],
    "file": "form_realisasi.2jnIK4Ad.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/tervalidasi/form_realisasi.vue"
  },
  "form_realisasi.WP_GPllY.css": {
    "file": "form_realisasi.WP_GPllY.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/tervalidasi/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.GM9XqvSc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "components/global/table.vue",
      "pages/adminDinas/tervalidasi/detail.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/tervalidasi/index.vue"
  },
  "pages/adminDinas/tidak-sesuai/detail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "detail.KRp3oh23.css"
    ],
    "file": "detail.E7l4rghQ.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/tidak-sesuai/detail.vue"
  },
  "detail.KRp3oh23.css": {
    "file": "detail.KRp3oh23.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/adminDinas/tidak-sesuai/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3ZUNFGX-.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "layouts/MainLayoutDinas.vue",
      "pages/adminDinas/tidak-sesuai/detail.vue",
      "components/global/table.vue",
      "_logo.Wn5S2geK.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/adminDinas/tidak-sesuai/index.vue"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "fa-brands-400.oeevBGvT.woff2",
      "fa-brands-400.xx3GxY8x.ttf",
      "fa-regular-400.PVU4YFxz.woff2",
      "fa-regular-400.uePn0SEG.ttf",
      "fa-solid-900.EFmN-a-a.woff2",
      "fa-solid-900.pvTPbGQT.ttf",
      "fa-v4compatibility.UXWK-ByV.woff2",
      "fa-v4compatibility.ywV-aTaQ.ttf"
    ],
    "css": [
      "login.o4pXUCNa.css"
    ],
    "file": "login.t8i4Dygy.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  },
  "login.o4pXUCNa.css": {
    "file": "login.o4pXUCNa.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/register.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "register.qVvAquVi.css"
    ],
    "file": "register.Rl3rArcl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/register.vue"
  },
  "register.qVvAquVi.css": {
    "file": "register.qVvAquVi.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dashboard.PZRqeuOC.css"
    ],
    "file": "dashboard.jlxvrJ0F.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header.nlsff_7B.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/dashboard.vue"
  },
  "dashboard.PZRqeuOC.css": {
    "file": "dashboard.PZRqeuOC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/dokumentasi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "dokumentasi.5DRPdzRx.css"
    ],
    "file": "dokumentasi.-o4c3E9n.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/dokumentasi.vue"
  },
  "dokumentasi.5DRPdzRx.css": {
    "file": "dokumentasi.5DRPdzRx.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/help.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "help.YAEr70iN.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/help.vue"
  },
  "pages/user/pengumuman_hasil.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "pengumuman_hasil.9OLe1tmy.css"
    ],
    "file": "pengumuman_hasil.ApTfNEdg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_jspdf.plugin.autotable.B7Xwiq1D.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js",
      "__commonjsHelpers.4gQjN7DL.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/pengumuman_hasil.vue"
  },
  "pengumuman_hasil.9OLe1tmy.css": {
    "file": "pengumuman_hasil.9OLe1tmy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/profile.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "profile.SrRIU3KW.css"
    ],
    "file": "profile.sGncMLD3.js",
    "imports": [
      "_header_2.AI9xFQzh.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/profile.vue"
  },
  "profile.SrRIU3KW.css": {
    "file": "profile.SrRIU3KW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/progress_dokumen.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "progress_dokumen.DuEb-xdt.css"
    ],
    "file": "progress_dokumen.N2YBoQLC.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/progress_dokumen.vue"
  },
  "progress_dokumen.DuEb-xdt.css": {
    "file": "progress_dokumen.DuEb-xdt.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/revisi_dokumen.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "revisi_dokumen.eoJVYR5N.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/revisi_dokumen.vue"
  },
  "pages/user/upload_dokumen.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "upload_dokumen.i4k_r7wr.css"
    ],
    "file": "upload_dokumen.FfaiwkBz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_header_2.AI9xFQzh.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/upload_dokumen.vue"
  },
  "upload_dokumen.i4k_r7wr.css": {
    "file": "upload_dokumen.i4k_r7wr.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/user/verifikasi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "verifikasi.dwNvN0Hq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_jspdf.plugin.autotable.B7Xwiq1D.js",
      "_header_2.AI9xFQzh.js",
      "__commonjsHelpers.4gQjN7DL.js",
      "_logo.WbOHzM7j.js",
      "_whatsapp.4GWqvSyA.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/user/verifikasi.vue"
  },
  "public/logo.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "logo.yjEE0l0b.png",
    "src": "public/logo.png"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
