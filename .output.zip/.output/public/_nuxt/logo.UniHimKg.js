import"./entry.2S6KxaLN.js";const r=""+new URL("logo.yjEE0l0b.png",import.meta.url).href;export{r as _};
